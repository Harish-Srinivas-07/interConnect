import slide1 from "./slide1.png";
import slide2 from "./slide2.png";
import slide3 from "./slide3.png";
import logo from './logo.png';
import playstore from './google_play_store.png';
import appstore from './apple_app_store.png';

export { slide1, slide2, slide3, logo, playstore, appstore };
